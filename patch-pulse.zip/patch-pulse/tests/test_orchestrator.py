from app.governance.policy import GovernancePolicy
from app.models import Vulnerability
from app.remediation.orchestrator import RemediationOrchestrator


class Settings:
    dry_run = True
    audit_file = "/tmp/patch-pulse-test-audit.jsonl"
    allowed_environments = frozenset({"dev", "staging"})
    allow_production = False
    ansible_timeout = 30
    retry_attempts = 1
    retry_backoff = 1
    jira_base_url = None
    jira_api_token = None
    jira_user_email = None
    jira_project_key = "SEC"
    jira_change_issue_type = "Change"


def test_tier3_does_not_execute():
    class Audit:
        def event(self, *args, **kwargs):
            pass

    policy = GovernancePolicy.from_file("config/config.yaml")
    orch = RemediationOrchestrator(Settings(), policy, Audit())
    vuln = Vulnerability(
        "CVE-X", "dc-01", "production", "critical",
        "domain-controller", "pkg", "1.0"
    )
    result = orch.process(vuln)
    assert result["tier"] == 3
    assert result["status"] == "CAB_APPROVAL_REQUIRED"
