import pytest
from app.models import Vulnerability


def test_missing_field_rejected():
    with pytest.raises(ValueError):
        Vulnerability.from_dict({"asset": "host1"})


def test_model_loads():
    v = Vulnerability.from_dict({
        "vulnerability_id": "CVE-X",
        "asset": "host1",
        "environment": "DEV",
        "severity": "MEDIUM",
        "asset_class": "server",
        "package": "openssl",
        "fixed_version": "3.0.1"
    })
    assert v.environment == "dev"
    assert v.severity == "medium"
