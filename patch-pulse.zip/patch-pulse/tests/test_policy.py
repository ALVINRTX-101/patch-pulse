from app.governance.policy import GovernancePolicy
from app.models import Vulnerability


class Settings:
    allowed_environments = frozenset({"dev", "staging"})
    allow_production = False


def make(**overrides):
    data = dict(
        vulnerability_id="CVE-X",
        asset="host1",
        environment="dev",
        severity="medium",
        asset_class="application-server",
        package="openssl",
        fixed_version="1.2.3",
    )
    data.update(overrides)
    return Vulnerability(**data)


def test_medium_dev_is_tier1():
    policy = GovernancePolicy.from_file("config/config.yaml")
    assert policy.tier_for(make()) == 1


def test_high_is_tier2():
    policy = GovernancePolicy.from_file("config/config.yaml")
    assert policy.tier_for(make(severity="high")) == 2


def test_critical_is_tier3():
    policy = GovernancePolicy.from_file("config/config.yaml")
    assert policy.tier_for(make(severity="critical")) == 3


def test_critical_asset_is_tier3():
    policy = GovernancePolicy.from_file("config/config.yaml")
    assert policy.tier_for(make(asset_class="domain-controller")) == 3
