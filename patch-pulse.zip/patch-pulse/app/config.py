import os
from dataclasses import dataclass


def env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    dry_run: bool
    log_level: str
    audit_file: str
    allowed_environments: frozenset[str]
    allow_production: bool
    ansible_timeout: int
    retry_attempts: int
    retry_backoff: float
    jira_base_url: str | None
    jira_api_token: str | None
    jira_user_email: str | None
    jira_project_key: str
    jira_change_issue_type: str
    jira_verify_status_names: frozenset[str]
    cab_required: bool
    cab_approval_url: str | None
    cab_api_token: str | None
    remediation_api_url: str | None
    remediation_api_token: str | None

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            dry_run=env_bool("PATCH_PULSE_DRY_RUN", True),
            log_level=os.getenv("PATCH_PULSE_LOG_LEVEL", "INFO"),
            audit_file=os.getenv("PATCH_PULSE_AUDIT_FILE", "./audit/patch-pulse-audit.jsonl"),
            allowed_environments=frozenset(x.strip().lower() for x in os.getenv(
                "PATCH_PULSE_ALLOWED_ENVIRONMENTS", "dev,staging").split(",") if x.strip()),
            allow_production=env_bool("PATCH_PULSE_ALLOW_PRODUCTION", False),
            ansible_timeout=int(os.getenv("PATCH_PULSE_ANSIBLE_TIMEOUT", "1800")),
            retry_attempts=max(1, int(os.getenv("PATCH_PULSE_RETRY_ATTEMPTS", "3"))),
            retry_backoff=float(os.getenv("PATCH_PULSE_RETRY_BACKOFF", "2")),
            jira_base_url=os.getenv("JIRA_BASE_URL"),
            jira_api_token=os.getenv("JIRA_API_TOKEN"),
            jira_user_email=os.getenv("JIRA_USER_EMAIL"),
            jira_project_key=os.getenv("JIRA_PROJECT_KEY", "SEC"),
            jira_change_issue_type=os.getenv("JIRA_STANDARD_CHANGE_ISSUE_TYPE", "Change"),
            jira_verify_status_names=frozenset(x.strip() for x in os.getenv(
                "JIRA_VERIFY_STATUS_NAMES", "Approved,Open,In Progress").split(",") if x.strip()),
            cab_required=env_bool("CAB_APPROVAL_REQUIRED", True),
            cab_approval_url=os.getenv("CAB_APPROVAL_URL"),
            cab_api_token=os.getenv("CAB_API_TOKEN"),
            remediation_api_url=os.getenv("REMEDIATION_API_URL"),
            remediation_api_token=os.getenv("REMEDIATION_API_TOKEN"),
        )
