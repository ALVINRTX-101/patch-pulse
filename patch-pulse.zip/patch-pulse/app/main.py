import argparse
import json
import sys
from pathlib import Path

from app.audit.logger import AuditLogger
from app.config import Settings
from app.governance.policy import GovernancePolicy
from app.models import Vulnerability
from app.remediation.orchestrator import RemediationOrchestrator


def load_vulnerabilities(path: str) -> list[Vulnerability]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise ValueError("Input JSON must be an array of vulnerabilities")
    return [Vulnerability.from_dict(item) for item in data]


def main() -> int:
    parser = argparse.ArgumentParser(prog="patch-pulse")
    sub = parser.add_subparsers(dest="command", required=True)

    remediate = sub.add_parser("remediate")
    remediate.add_argument("--input", required=True, help="Vulnerability JSON file")
    remediate.add_argument("--config", default="config/config.yaml")

    args = parser.parse_args()

    try:
        settings = Settings.from_env()
        audit = AuditLogger(settings.audit_file)
        policy = GovernancePolicy.from_file(args.config)
        orchestrator = RemediationOrchestrator(settings, policy, audit)

        vulnerabilities = load_vulnerabilities(args.input)
        results = [orchestrator.process(v) for v in vulnerabilities]

        print(json.dumps(results, indent=2))
        return 0 if all(r["success"] for r in results) else 2
    except Exception as exc:
        print(f"patch-pulse failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
