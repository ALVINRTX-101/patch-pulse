from dataclasses import dataclass


@dataclass(frozen=True)
class Vulnerability:
    vulnerability_id: str
    asset: str
    environment: str
    severity: str
    asset_class: str
    package: str
    fixed_version: str
    description: str = ""

    @classmethod
    def from_dict(cls, item: dict) -> "Vulnerability":
        required = [
            "vulnerability_id", "asset", "environment", "severity",
            "asset_class", "package", "fixed_version"
        ]
        missing = [key for key in required if not item.get(key)]
        if missing:
            raise ValueError(f"Missing vulnerability fields: {', '.join(missing)}")

        return cls(
            vulnerability_id=str(item["vulnerability_id"]),
            asset=str(item["asset"]),
            environment=str(item["environment"]).lower(),
            severity=str(item["severity"]).lower(),
            asset_class=str(item["asset_class"]).lower(),
            package=str(item["package"]),
            fixed_version=str(item["fixed_version"]),
            description=str(item.get("description", "")),
        )
