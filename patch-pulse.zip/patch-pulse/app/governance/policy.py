import yaml

from app.models import Vulnerability


class GovernancePolicy:
    def __init__(self, config: dict):
        self.config = config

    @classmethod
    def from_file(cls, path: str) -> "GovernancePolicy":
        with open(path, encoding="utf-8") as fh:
            return cls(yaml.safe_load(fh) or {})

    def tier_for(self, vuln: Vulnerability) -> int:
        gov = self.config["governance"]
        tier3_classes = set(gov["tier3"]["critical_asset_classes"])
        if vuln.severity == "critical" or vuln.asset_class in tier3_classes:
            return 3

        tier2_envs = set(gov["tier2"]["environments"])
        if vuln.severity == "high" or vuln.environment in tier2_envs:
            return 2

        return 1

    def validate_scope(self, vuln: Vulnerability, tier: int, settings) -> None:
        if tier == 1 and vuln.environment not in settings.allowed_environments:
            raise PermissionError(
                f"Tier 1 blocked: environment '{vuln.environment}' is outside allowed scope"
            )

        if vuln.environment == "production" and not settings.allow_production and tier != 3:
            raise PermissionError("Production remediation is disabled by configuration")
