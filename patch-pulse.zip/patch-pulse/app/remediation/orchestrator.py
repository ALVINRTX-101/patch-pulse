import time

from app.remediation.ansible import AnsibleRunner
from app.remediation.jira import JiraClient


class RemediationOrchestrator:
    def __init__(self, settings, policy, audit):
        self.settings = settings
        self.policy = policy
        self.audit = audit
        self.ansible = AnsibleRunner(settings.ansible_timeout, settings.dry_run)

    def process(self, vuln):
        tier = self.policy.tier_for(vuln)
        self.audit.event(
            "governance_classified",
            vulnerability_id=vuln.vulnerability_id,
            asset=vuln.asset,
            environment=vuln.environment,
            severity=vuln.severity,
            tier=tier,
        )

        try:
            self.policy.validate_scope(vuln, tier, self.settings)

            if tier == 1:
                return self._tier1(vuln)

            if tier == 2:
                return self._tier2(vuln)

            return self._tier3(vuln)

        except Exception as exc:
            self.audit.event(
                "remediation_failed",
                vulnerability_id=vuln.vulnerability_id,
                asset=vuln.asset,
                error=str(exc),
            )
            return {
                "success": False,
                "vulnerability_id": vuln.vulnerability_id,
                "tier": tier,
                "error": str(exc),
            }

    def _tier1(self, vuln):
        inventory = f"ansible/inventory/{vuln.environment}"
        playbook = "ansible/patch_linux.yml"

        result = self._with_retry(
            lambda: self.ansible.run(
                playbook,
                inventory,
                {
                    "target_host": vuln.asset,
                    "package_name": vuln.package,
                    "fixed_version": vuln.fixed_version,
                },
            )
        )

        self.audit.event(
            "tier1_remediation",
            vulnerability_id=vuln.vulnerability_id,
            asset=vuln.asset,
            result=result,
        )
        return {
            "success": result["success"],
            "vulnerability_id": vuln.vulnerability_id,
            "tier": 1,
            "result": result,
        }

    def _tier2(self, vuln):
        if self.settings.dry_run:
            result = {"dry_run": True, "message": "Jira Standard Change would be created"}
        else:
            client = JiraClient(
                self.settings.jira_base_url,
                self.settings.jira_api_token,
                self.settings.jira_user_email,
                self.settings.jira_project_key,
                self.settings.jira_change_issue_type,
            )
            result = client.create_standard_change(vuln)

        self.audit.event(
            "tier2_change_created",
            vulnerability_id=vuln.vulnerability_id,
            asset=vuln.asset,
            change=result,
        )

        # Deliberate governance gate: Tier 2 does not auto-execute from this command.
        return {
            "success": True,
            "vulnerability_id": vuln.vulnerability_id,
            "tier": 2,
            "status": "CHANGE_REQUEST_REQUIRED",
            "change": result,
        }

    def _tier3(self, vuln):
        self.audit.event(
            "tier3_cab_required",
            vulnerability_id=vuln.vulnerability_id,
            asset=vuln.asset,
            severity=vuln.severity,
        )
        return {
            "success": True,
            "vulnerability_id": vuln.vulnerability_id,
            "tier": 3,
            "status": "CAB_APPROVAL_REQUIRED",
            "message": "No remediation was executed.",
        }

    def _with_retry(self, operation):
        last_error = None
        for attempt in range(1, self.settings.retry_attempts + 1):
            try:
                return operation()
            except Exception as exc:
                last_error = exc
                if attempt == self.settings.retry_attempts:
                    raise
                time.sleep(self.settings.retry_backoff ** (attempt - 1))
        raise last_error
