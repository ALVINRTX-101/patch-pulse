import requests


class JiraClient:
    def __init__(self, base_url, token, email, project_key, issue_type, timeout=30):
        self.base_url = (base_url or "").rstrip("/")
        self.token = token
        self.email = email
        self.project_key = project_key
        self.issue_type = issue_type
        self.timeout = timeout

    def create_standard_change(self, vuln) -> dict:
        if not all([self.base_url, self.token, self.email]):
            raise RuntimeError("Jira configuration is incomplete")

        url = f"{self.base_url}/rest/api/2/issue"
        payload = {
            "fields": {
                "project": {"key": self.project_key},
                "summary": f"Patch {vuln.vulnerability_id} on {vuln.asset}",
                "description": (
                    f"Vulnerability: {vuln.vulnerability_id}\n"
                    f"Asset: {vuln.asset}\nPackage: {vuln.package}\n"
                    f"Target version: {vuln.fixed_version}\nSeverity: {vuln.severity}"
                ),
                "issuetype": {"name": self.issue_type},
            }
        }
        response = requests.post(
            url,
            json=payload,
            auth=(self.email, self.token),
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json()

    def get_issue(self, issue_key: str) -> dict:
        response = requests.get(
            f"{self.base_url}/rest/api/2/issue/{issue_key}",
            auth=(self.email, self.token),
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json()
