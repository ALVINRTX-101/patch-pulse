import subprocess
from pathlib import Path


class AnsibleRunner:
    def __init__(self, timeout: int, dry_run: bool):
        self.timeout = timeout
        self.dry_run = dry_run

    def run(self, playbook: str, inventory: str, extra_vars: dict) -> dict:
        command = [
            "ansible-playbook",
            "-i", inventory,
            playbook,
            "--extra-vars", self._extra_vars(extra_vars),
        ]

        if self.dry_run:
            return {"success": True, "dry_run": True, "command": command}

        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=self.timeout,
            check=False,
        )
        return {
            "success": completed.returncode == 0,
            "returncode": completed.returncode,
            "stdout": completed.stdout[-10000:],
            "stderr": completed.stderr[-10000:],
        }

    @staticmethod
    def _extra_vars(values: dict) -> str:
        # Values originate from validated vulnerability metadata.
        import json
        return json.dumps(values)
